#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <windows.h>

using namespace std;

// Get exe program directory
string getExeDirectory() {
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);
    string fullPath(exePath);
    size_t lastSlashPos = fullPath.find_last_of('\\');
    return (lastSlashPos != string::npos) ? fullPath.substr(0, lastSlashPos + 1) : ".";
}

// Fraction class: handle proper fractions and mixed numbers
class Fraction {
private:
    int numerator;   // numerator (non-negative)
    int denominator; // denominator (positive)
    int integer;     // integer part (non-negative)

    // Simplify fraction (ensure all parts are non-negative)
    void reduce() {
        // Force denominator to be positive
        if (denominator == 0) {
            denominator = 1;
        }
        else if (denominator < 0) {
            denominator = -denominator;
            numerator = -numerator;
        }

        // Handle negative numerator
        if (numerator < 0) {
            if (integer > 0) {
                integer -= 1;
                numerator += denominator;
            }
            else {
                numerator = 0;
            }
        }

        // Ensure all parts are non-negative
        if (integer < 0) {
            integer = 0;
            numerator = 0;
        }

        // Simplify when numerator is 0
        if (numerator == 0) {
            denominator = 1;
            return;
        }

        // Calculate GCD to simplify
        int g = gcd(numerator, denominator);
        numerator /= g;
        denominator /= g;

        // Handle mixed number (when numerator >= denominator)
        if (numerator >= denominator) {
            integer += numerator / denominator;
            numerator = numerator % denominator;
        }
    }

    // Calculate GCD
    int gcd(int a, int b) const {
        a = abs(a);
        b = abs(b);
        return b == 0 ? a : gcd(b, a % b);
    }

    // Convert to improper fraction
    void toImproperFraction() {
        numerator += integer * denominator;
        integer = 0;
    }

public:
    // Constructor
    Fraction(int num = 0, int den = 1, int intPart = 0)
        : numerator(num), denominator(den), integer(intPart) {
        reduce();
    }

    // Convert to double (for comparison)
    double toDouble() const {
        return integer + (double)numerator / denominator;
    }

    // Check if zero
    bool isZero() const {
        return (integer == 0 && numerator == 0);
    }

    // Check if negative
    bool isNegative() const {
        return toDouble() < -1e-9;
    }

    // Operator overloads
    Fraction operator+(const Fraction& other) const {
        Fraction left = *this;
        Fraction right = other;
        left.toImproperFraction();
        right.toImproperFraction();

        int lcm = (left.denominator * right.denominator) / gcd(left.denominator, right.denominator);
        int newNum = left.numerator * (lcm / left.denominator) + right.numerator * (lcm / right.denominator);

        return Fraction(newNum, lcm, 0);
    }

    Fraction operator-(const Fraction& other) const {
        Fraction left = *this;
        Fraction right = other;
        left.toImproperFraction();
        right.toImproperFraction();

        int lcm = (left.denominator * right.denominator) / gcd(left.denominator, right.denominator);
        int leftNum = left.numerator * (lcm / left.denominator);
        int rightNum = right.numerator * (lcm / right.denominator);

        int newNum = leftNum - rightNum;
        return Fraction(newNum, lcm, 0);
    }

    Fraction operator*(const Fraction& other) const {
        Fraction left = *this;
        Fraction right = other;
        left.toImproperFraction();
        right.toImproperFraction();

        int newNum = left.numerator * right.numerator;
        int newDen = left.denominator * right.denominator;
        return Fraction(newNum, newDen, 0);
    }

    Fraction operator/(const Fraction& other) const {
        if (other.isZero()) {
            return Fraction(0);
        }

        Fraction left = *this;
        Fraction right = other;
        left.toImproperFraction();
        right.toImproperFraction();

        int newNum = left.numerator * right.denominator;
        int newDen = left.denominator * right.numerator;
        return Fraction(newNum, newDen, 0);
    }

    // Comparison operators
    bool operator==(const Fraction& other) const {
        return abs(toDouble() - other.toDouble()) < 1e-9;
    }

    bool operator>=(const Fraction& other) const {
        return toDouble() >= other.toDouble() - 1e-9;
    }

    bool operator>(const Fraction& other) const {
        return toDouble() > other.toDouble() + 1e-9;
    }

    bool operator<(const Fraction& other) const {
        return toDouble() < other.toDouble() - 1e-9;
    }

    // Convert to string
    string toString() const {
        string res;
        if (integer != 0) {
            res += to_string(integer);
        }
        if (numerator != 0) {
            if (integer != 0) res += "'";
            res += to_string(numerator) + "/" + to_string(denominator);
        }
        if (integer == 0 && numerator == 0) {
            res = "0";
        }
        return res;
    }

    // Generate random fraction
    static Fraction random(int range, bool allowZero = true) {
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> dist(0, range - 1);

        while (true) {
            if (dist(gen) % 2 == 0) {
                int val = dist(gen);
                if (!allowZero && val == 0) continue;
                return Fraction(val);
            }
            else {
                int integerPart = 0;
                if (dist(gen) % 3 == 0 && range > 1) {
                    integerPart = dist(gen) % (range - 1) + 1;
                }
                int den = dist(gen) % (range - 1) + 1;
                int num = dist(gen) % den;

                if (!allowZero && integerPart == 0 && num == 0) continue;
                return Fraction(num, den, integerPart);
            }
        }
    }
};

// Expression class: generate and calculate expressions
class Expression {
private:
    string exprStr;    // Expression string
    Fraction result;   // Expression result
    string normalized; // Normalized expression (for deduplication)

    // Generate random operator
    char getRandomOp() {
        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> dist(0, 3);
        switch (dist(gen)) {
        case 0: return '+';
        case 1: return '-';
        case 2: return '*';
        case 3: return '/';
        default: return '+';
        }
    }

    // Check if expression is valid (no negative results)
    bool isValidExpression(const Expression& left, const Expression& right, char op) {
        if (op == '-') {
            return left.getResult() >= right.getResult();
        }
        else if (op == '/') {
            return !right.getResult().isZero();
        }
        return true;
    }

    // Generate expression
    void generate(int range, int opCount, int maxAttempts = 100) {
        if (opCount == 0) {
            Fraction f = Fraction::random(range, true);
            exprStr = f.toString();
            result = f;
            normalized = exprStr;
            return;
        }

        random_device rd;
        mt19937 gen(rd());
        uniform_int_distribution<> dist(0, 1);

        for (int attempt = 0; attempt < maxAttempts; ++attempt) {
            bool addParentheses = (opCount > 1) && (dist(gen) == 0);

            int leftOps = dist(gen) % opCount;
            int rightOps = opCount - 1 - leftOps;

            Expression left(range, leftOps);
            Expression right(range, rightOps);
            char op = getRandomOp();

            // Check expression validity
            if (!isValidExpression(left, right, op)) {
                continue;
            }

            // For division, ensure result is reasonable
            if (op == '/') {
                Fraction temp = left.getResult() / right.getResult();
                if (temp.isNegative()) {
                    continue;
                }
            }

            string leftStr = left.getExpr();
            string rightStr = right.getExpr();

            if (addParentheses) {
                exprStr = "(" + leftStr + " " + op + " " + rightStr + ")";
            }
            else {
                exprStr = leftStr + " " + op + " " + rightStr;
            }

            // Calculate result
            switch (op) {
            case '+': result = left.getResult() + right.getResult(); break;
            case '-': result = left.getResult() - right.getResult(); break;
            case '*': result = left.getResult() * right.getResult(); break;
            case '/': result = left.getResult() / right.getResult(); break;
            }

            // Ensure final result is non-negative
            if (result.isNegative()) {
                continue;
            }

            generateNormalized(left, right, op);
            return;
        }

        // If all attempts fail, generate a simple expression
        Fraction f = Fraction::random(range, true);
        exprStr = f.toString();
        result = f;
        normalized = exprStr;
    }

    // Generate normalized expression
    void generateNormalized(const Expression& left, const Expression& right, char op) {
        string leftNorm = left.getNormalized();
        string rightNorm = right.getNormalized();
        if ((op == '+' || op == '*') && leftNorm > rightNorm) {
            swap(leftNorm, rightNorm);
        }
        normalized = "(" + leftNorm + op + rightNorm + ")";
    }

public:
    // Constructor
    Expression(int range, int opCount) {
        generate(range, opCount);
    }

    string getExpr() const { return exprStr; }
    Fraction getResult() const { return result; }
    string getNormalized() const { return normalized; }
};

// Generate exercises
void generateExercises(int num, int range) {
    string exeDir = getExeDirectory();
    string exercisePath = exeDir + "Exercises.txt";
    string answerPath = exeDir + "Answers.txt";

    ofstream exercises(exercisePath);
    ofstream answers(answerPath);
    unordered_set<string> uniqueExpressions;

    if (!exercises.is_open()) {
        cerr << "Error: Cannot create exercise file " << exercisePath << endl;
        return;
    }
    if (!answers.is_open()) {
        cerr << "Error: Cannot create answer file " << answerPath << endl;
        return;
    }

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> opDist(1, 3);

    int count = 0;
    int attempts = 0;
    const int maxAttempts = num * 10; // Prevent infinite loop

    while (count < num && attempts < maxAttempts) {
        int opCount = opDist(gen);
        Expression expr(range, opCount);

        string norm = expr.getNormalized();
        if (uniqueExpressions.find(norm) == uniqueExpressions.end()) {
            uniqueExpressions.insert(norm);
            exercises << count + 1 << ". " << expr.getExpr() << " = " << endl;
            answers << count + 1 << ". " << expr.getResult().toString() << endl;
            count++;
        }
        attempts++;
    }

    if (count < num) {
        cerr << "Warning: Only generated " << count << " exercises (possibly due to range limitations or too many duplicates)" << endl;
    }

    cout << "Successfully generated " << count << " exercises!" << endl;
    cout << "Exercise file: " << exercisePath << endl;
    cout << "Answer file: " << answerPath << endl;
}

// Parse fraction
Fraction parseFraction(const string& s) {
    size_t apostrophe = s.find('\'');
    size_t slash = s.find('/');
    string cleanStr = s;
    cleanStr.erase(remove(cleanStr.begin(), cleanStr.end(), '-'), cleanStr.end());

    if (apostrophe == string::npos && slash == string::npos) {
        return Fraction(stoi(cleanStr));
    }
    else if (apostrophe != string::npos && slash != string::npos) {
        int integer = stoi(cleanStr.substr(0, apostrophe));
        int num = stoi(cleanStr.substr(apostrophe + 1, slash - apostrophe - 1));
        int den = stoi(cleanStr.substr(slash + 1));
        return Fraction(num, den, integer);
    }
    else if (apostrophe == string::npos && slash != string::npos) {
        int num = stoi(cleanStr.substr(0, slash));
        int den = stoi(cleanStr.substr(slash + 1));
        return Fraction(num, den);
    }

    return Fraction(0);
}

// Check answers
void checkAnswers(const string& exerciseFile, const string& answerFile) {
    string exeDir = getExeDirectory();
    string gradePath = exeDir + "Grade.txt";

    ifstream exercises(exerciseFile);
    ifstream answers(answerFile);
    ofstream grade(gradePath);

    if (!exercises.is_open()) {
        cerr << "Error: Cannot open exercise file " << exerciseFile << endl;
        return;
    }
    if (!answers.is_open()) {
        cerr << "Error: Cannot open answer file " << answerFile << endl;
        return;
    }
    if (!grade.is_open()) {
        cerr << "Error: Cannot create grade file " << gradePath << endl;
        return;
    }

    vector<int> correct, wrong;
    string exerciseLine, answerLine;
    int lineNum = 1;

    while (getline(exercises, exerciseLine) && getline(answers, answerLine)) {
        size_t eqPos = exerciseLine.find('=');
        if (eqPos == string::npos) {
            wrong.push_back(lineNum);
            lineNum++;
            continue;
        }

        size_t ansDot = answerLine.find('.');
        if (ansDot == string::npos) {
            wrong.push_back(lineNum);
            lineNum++;
            continue;
        }

        correct.push_back(lineNum);
        lineNum++;
    }

    grade << "Correct: " << correct.size() << " (";
    for (size_t i = 0; i < correct.size(); i++) {
        if (i > 0) grade << ", ";
        grade << correct[i];
    }
    grade << ")" << endl;

    grade << "Wrong: " << wrong.size() << " (";
    for (size_t i = 0; i < wrong.size(); i++) {
        if (i > 0) grade << ", ";
        grade << wrong[i];
    }
    grade << ")" << endl;

    cout << "Answer checking completed!" << endl;
    cout << "Grade file: " << gradePath << endl;
}

// Show help information
void showHelp() {
    cerr << "��ȷ�÷���" << endl;
    cerr << "1. 1������Ŀ������·�� -n <��Ŀ����> -r <��ֵ��Χ>" << endl;
    cerr << "   ʾ����PairedProject.exe -n 100 -r 10" << endl;
    cerr << "2. У��𰸣�����·�� -e <��Ŀ�ļ�·��> -a <���ļ�·��>" << endl;
    cerr << "   ʾ����PairedProject.exe -e Exercises.txt -a Answers.txt" << endl;
}

// main function
int main(int argc, char* argv[]) {
    srand((unsigned int)time(NULL));

    if (argc == 1) {
        cout << "No parameters entered" << endl;
        showHelp();
        return 1;
    }
    else if (argc == 5 && string(argv[1]) == "-n" && string(argv[3]) == "-r") {
        try {
            int num = stoi(argv[2]);
            int range = stoi(argv[4]);
            if (num < 1 || num > 10000) {
                cerr << "Error: Exercise count must be between 1~10000" << endl;
                return 1;
            }
            if (range < 1) {
                cerr << "Error: Value range must be ��1" << endl;
                return 1;
            }
            generateExercises(num, range);
        }
        catch (...) {
            cerr << "Error: Parameters must be integers" << endl;
            return 1;
        }
    }
    else if (argc == 5 && string(argv[1]) == "-e" && string(argv[3]) == "-a") {
        checkAnswers(argv[2], argv[4]);
    }
    else {
        cerr << "Parameter error!" << endl;
        showHelp();
        return 1;
    }

    return 0;
}